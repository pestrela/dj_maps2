

WHICH VERSION TO CHOOSE:
------------------------
  This zip file has two versions of the mapping: WITH or WITHOUT bome.

  a) the WITH bome version is much newer, has jog screens, and has all the new features like smoooth echo. 
    The Con is that installation is more complex and a BOME license costs 60 eur (after testing).
    
  b) the WITHOUT bome version is very old, but complete. No extra costs required.


DOCUMENTATION:
--------------
 Be sure to check the QUICK_START.pdf and REFERENCE.pdf files.
 
 QUICK START has the most CRUCIAL INFORMATION:
  - available documentation
  - differences to rekordbox
  - how to ENABLE advanced features 
  
 The REFERENCE file has tables with all the buttons, incluiding all gestures and shifts.

 The INSTALLATION guide and FULL MANUAL are in "\bome version\Documentation"
 
